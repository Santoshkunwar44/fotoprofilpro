 const Enums={
    SEND_RESPONSE:"SEND_RESPONSE"
}
module.exports = Enums